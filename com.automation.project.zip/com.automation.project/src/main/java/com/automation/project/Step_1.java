package com.automation.project;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Step_1 {

	public static WebDriver driver;
	

		public void Browser_Launch(String url) {
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.get(url);
		}

		
	public void Login_Process() throws InterruptedException
		{
			
		 WebElement desiredCity = driver.findElement(By.xpath("//img[@alt='BANG']"));
	     desiredCity.click();
        
		WebElement SignButton = driver.findElement(By.xpath("//div[@class='sc-iGPElx jsSlsO']"));
        SignButton.click();

        WebElement ContinueEmailButton = driver.findElement(By.xpath("//div[contains(text(),'Continue with Email')]"));
        ContinueEmailButton.click();

        WebElement emailField = driver.findElement(By.xpath("//input[@id='emailId']"));
        emailField.sendKeys("selauto@yopmail.com ");
        
        WebElement ContinueButton = driver.findElement(By.xpath("//button[normalize-space()='Continue']"));
        ContinueButton.click();
        
        WebElement OTPButton = driver.findElement(By.xpath("//div[@class='sc-gZMcBi sc-jzgbtB grnTcO']"));
        OTPButton.click();
        

		String Exp_title="Hi, Guest";
		String Actual_title=driver.getTitle();
		
		if(Exp_title.equals(Actual_title))
		{
			System.out.println("User Verifed");
		}
		else
		{
			System.out.println("User Not Verifed");
		}
			
		}
		

}
