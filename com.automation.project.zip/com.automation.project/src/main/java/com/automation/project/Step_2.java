package com.automation.project;

public class Step_2 {
	
	public static void main(String[] args) throws InterruptedException {
	
	Step_1 obj=new Step_1();
	String url="https://in.bookmyshow.com/explore/home/";
	obj.Browser_Launch(url);
	
	
	}
}
